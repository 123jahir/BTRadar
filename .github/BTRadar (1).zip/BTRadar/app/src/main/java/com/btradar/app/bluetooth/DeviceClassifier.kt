package com.btradar.app.bluetooth

import java.nio.ByteOrder
import java.nio.ByteBuffer

/**
 * Classifies Bluetooth devices based on:
 * - Manufacturer data (company ID from Bluetooth SIG assigned numbers)
 * - Service UUIDs (standard BLE profiles)
 * - Device name patterns
 */
object DeviceClassifier {

    // Bluetooth SIG assigned company IDs
    private const val COMPANY_APPLE      = 0x004C
    private const val COMPANY_SAMSUNG    = 0x0075
    private const val COMPANY_MICROSOFT  = 0x0006
    private const val COMPANY_GOOGLE     = 0x00E0
    private const val COMPANY_XIAOMI     = 0x038F
    private const val COMPANY_BOSE       = 0x009E
    private const val COMPANY_SONY       = 0x012D

    // Apple subtypes in manufacturer data byte[2]
    private const val APPLE_SUBTYPE_AIRTAG   = 0x12
    private const val APPLE_SUBTYPE_FINDMY   = 0x12
    private const val APPLE_SUBTYPE_AIRPODS  = 0x07
    private const val APPLE_SUBTYPE_WATCH    = 0x0B

    // Standard BLE Service UUIDs (16-bit short form)
    private const val UUID_HEART_RATE       = "180d"
    private const val UUID_CYCLING_SPEED    = "1816"
    private const val UUID_HID              = "1812"
    private const val UUID_A2DP_SINK        = "110b"
    private const val UUID_A2DP_SOURCE      = "110a"
    private const val UUID_HANDSFREE        = "111e"
    private const val UUID_BATTERY          = "180f"
    private const val UUID_DEVICE_INFO      = "180a"

    fun classify(
        name: String?,
        serviceUuids: List<String>,
        manufacturerData: ByteArray?
    ): DeviceClassification {

        val nameLower = name?.lowercase() ?: ""

        // ── Manufacturer ID analysis ──────────────────────────────────────────
        if (manufacturerData != null && manufacturerData.size >= 2) {
            val companyId = ByteBuffer.wrap(manufacturerData)
                .order(ByteOrder.LITTLE_ENDIAN)
                .short.toInt() and 0xFFFF

            when (companyId) {
                COMPANY_APPLE -> {
                    // Check Apple subtype for specific devices
                    val subtype = if (manufacturerData.size > 2) manufacturerData[2].toInt() and 0xFF else -1
                    return when (subtype) {
                        APPLE_SUBTYPE_AIRTAG ->
                            DeviceClassification(DeviceType.TRACKER, "Apple AirTag / FindMy", "🏷️", isThreat = true)
                        APPLE_SUBTYPE_AIRPODS ->
                            DeviceClassification(DeviceType.HEADPHONES, "Apple AirPods", "🎧")
                        APPLE_SUBTYPE_WATCH ->
                            DeviceClassification(DeviceType.SMARTWATCH, "Apple Watch", "⌚")
                        else ->
                            DeviceClassification(DeviceType.APPLE, "Apple Device", "🍎")
                    }
                }
                COMPANY_SAMSUNG ->
                    return DeviceClassification(DeviceType.SAMSUNG, "Samsung Device", "📱")
                COMPANY_MICROSOFT ->
                    return DeviceClassification(DeviceType.WINDOWS, "Windows Device", "💻")
                COMPANY_GOOGLE ->
                    return DeviceClassification(DeviceType.PHONE, "Google Device", "📱")
                COMPANY_XIAOMI ->
                    return DeviceClassification(DeviceType.PHONE, "Xiaomi Device", "📱")
                COMPANY_BOSE ->
                    return DeviceClassification(DeviceType.HEADPHONES, "Bose Audio", "🎧")
                COMPANY_SONY ->
                    return DeviceClassification(DeviceType.HEADPHONES, "Sony Device", "🎧")
            }
        }

        // ── Service UUID analysis ─────────────────────────────────────────────
        val uuidsLower = serviceUuids.map { it.lowercase() }
        when {
            UUID_HEART_RATE in uuidsLower ->
                return DeviceClassification(DeviceType.HEALTH, "Heart Rate Monitor", "❤️")
            UUID_CYCLING_SPEED in uuidsLower ->
                return DeviceClassification(DeviceType.CYCLING, "Cycling Sensor", "🚲")
            UUID_HID in uuidsLower ->
                return DeviceClassification(DeviceType.HID, "HID Device (keyboard/mouse)", "⌨️")
            UUID_A2DP_SINK in uuidsLower || UUID_A2DP_SOURCE in uuidsLower ->
                return DeviceClassification(DeviceType.AUDIO_CLASSIC, "A2DP Audio Device", "🎵")
            UUID_HANDSFREE in uuidsLower ->
                return DeviceClassification(DeviceType.HEADPHONES, "Hands-Free Device", "🎧")
        }

        // ── Name pattern matching ─────────────────────────────────────────────
        return when {
            nameLower.matchesAny("airpod", "earbud", "headphone", "headset", "buds",
                "jabra", "bose", "sennheiser", "sony wh", "wf-", "jbl", "wh-", "ep-") ->
                DeviceClassification(DeviceType.HEADPHONES, "Headphones / Earbuds", "🎧")

            nameLower.matchesAny("watch", "band", "fit", "garmin", "fitbit",
                "mi band", "galaxy watch", "versa", "charge") ->
                DeviceClassification(DeviceType.SMARTWATCH, "Smartwatch / Wearable", "⌚")

            nameLower.matchesAny("iphone", "galaxy", "pixel", "oneplus",
                "xiaomi", "redmi", "phone", "nokia", "huawei", "poco") ->
                DeviceClassification(DeviceType.PHONE, "Smartphone", "📱")

            nameLower.matchesAny("macbook", "laptop", "thinkpad", " dell", "hp ",
                "lenovo", "surface", "notebook") ->
                DeviceClassification(DeviceType.LAPTOP, "Laptop", "💻")

            nameLower.matchesAny("tv ", "television", "roku", "firestick",
                "chromecast", "smart tv", "bravia", "lg oled") ->
                DeviceClassification(DeviceType.TV, "Smart TV / Streaming", "📺")

            nameLower.matchesAny("keyboard", "mouse", "trackpad", "mx keys",
                "mx master", "logitech", "magic keyboard") ->
                DeviceClassification(DeviceType.PERIPHERAL, "Input Device", "⌨️")

            nameLower.matchesAny("speaker", "soundbar", "jbl", "marshall",
                "harman", "echo", "homepod", "sonos") ->
                DeviceClassification(DeviceType.SPEAKER, "Speaker", "🔊")

            nameLower.matchesAny("tag", "tracker", "tile ", "chipolo",
                "airtag", "smarttag", "galaxy tag") ->
                DeviceClassification(DeviceType.TRACKER, "Tracker Beacon", "🏷️", isThreat = true)

            else ->
                DeviceClassification(DeviceType.UNKNOWN, "Unknown Device", "📡")
        }
    }

    private fun String.matchesAny(vararg patterns: String): Boolean =
        patterns.any { this.contains(it, ignoreCase = true) }
}
