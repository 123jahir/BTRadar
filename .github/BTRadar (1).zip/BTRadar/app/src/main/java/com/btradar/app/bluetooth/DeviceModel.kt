package com.btradar.app.bluetooth

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a detected Bluetooth/BLE device with all signal + identity data
 */
data class DeviceModel(
    val mac: String,
    val name: String?,
    val rssi: Int,
    val rssiHistory: MutableList<Int> = mutableListOf(),
    val distance: Float,
    val signalQuality: SignalQuality,
    val classification: DeviceClassification,
    val movement: Movement,
    val firstSeen: Long,
    val lastSeen: Long,
    val seenCount: Int,
    val txPower: Int?,
    val serviceUuids: List<String>,
    val connectable: Boolean,
    val manufacturerData: ByteArray?,
    val isNew: Boolean = false
) {
    val displayName: String get() = name ?: "Unknown (${mac.takeLast(8)})"

    enum class Movement { STABLE, APPROACHING, RECEDING }

    enum class SignalQuality(val label: String) {
        EXCELLENT("EXCELLENT"),
        GOOD("GOOD"),
        FAIR("FAIR"),
        WEAK("WEAK"),
        VERY_WEAK("VERY WEAK")
    }

    companion object {
        fun signalQualityFromRssi(rssi: Int): SignalQuality = when {
            rssi >= -50 -> SignalQuality.EXCELLENT
            rssi >= -60 -> SignalQuality.GOOD
            rssi >= -70 -> SignalQuality.FAIR
            rssi >= -80 -> SignalQuality.WEAK
            else        -> SignalQuality.VERY_WEAK
        }
    }
}

data class DeviceClassification(
    val type: DeviceType,
    val label: String,
    val emoji: String,
    val isThreat: Boolean = false
)

enum class DeviceType {
    PHONE, HEADPHONES, SPEAKER, SMARTWATCH,
    LAPTOP, TV, PERIPHERAL, TRACKER,
    HEALTH, CYCLING, HID, AUDIO_CLASSIC,
    APPLE, SAMSUNG, WINDOWS, UNKNOWN
}

// Room entity for history persistence
@Entity(tableName = "device_history")
data class DeviceHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val mac: String,
    val name: String?,
    val firstSeen: Long,
    val lastSeen: Long,
    val maxRssi: Int,
    val classification: String,
    val seenCount: Int
)
