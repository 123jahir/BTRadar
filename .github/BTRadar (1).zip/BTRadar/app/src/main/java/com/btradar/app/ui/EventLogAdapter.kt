package com.btradar.app.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.btradar.app.bluetooth.ScanEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class EventLogAdapter : ListAdapter<ScanEvent, EventLogAdapter.VH>(DIFF) {

    private val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_2, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(getItem(position), sdf)
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val text1: TextView = view.findViewById(android.R.id.text1)
        val text2: TextView = view.findViewById(android.R.id.text2)

        fun bind(event: ScanEvent, sdf: SimpleDateFormat) {
            val time = sdf.format(Date(event.time))
            val (icon, label, color) = when (event.type) {
                ScanEvent.Type.APPEARED     -> Triple("+", "APPEARED", "#00ff6a")
                ScanEvent.Type.DISAPPEARED  -> Triple("-", "LOST",     "#4a7a5a")
                ScanEvent.Type.ALERT        -> Triple("⚠", "ALERT",    "#ff3b3b")
            }

            text1.text = "[$time] $icon ${event.name ?: event.mac}"
            text2.text = event.message ?: "~${
                if (event.distance > 0) "%.1fm".format(event.distance) else "?"
            }  ·  ${event.classificationLabel}"

            text1.setTextColor(Color.parseColor(color))
            text2.setTextColor(Color.parseColor("#3d6b4f"))
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<ScanEvent>() {
            override fun areItemsTheSame(a: ScanEvent, b: ScanEvent) =
                a.time == b.time && a.mac == b.mac && a.type == b.type
            override fun areContentsTheSame(a: ScanEvent, b: ScanEvent) = a == b
        }
    }
}
