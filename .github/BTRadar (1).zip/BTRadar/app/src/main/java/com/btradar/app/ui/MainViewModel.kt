package com.btradar.app.ui

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.btradar.app.bluetooth.BluetoothScanService
import com.btradar.app.bluetooth.DeviceModel
import com.btradar.app.bluetooth.ScanEvent
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private var scanService: BluetoothScanService? = null

    val devices: StateFlow<List<DeviceModel>> =
        BluetoothScanService.devicesFlow
            .map { map ->
                map.values
                    .sortedByDescending { it.rssi }
                    .toList()
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val scanActive: StateFlow<Boolean> =
        BluetoothScanService.scanActiveFlow
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val eventLog: StateFlow<List<ScanEvent>> =
        BluetoothScanService.eventLogFlow
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stats: StateFlow<RadarStats> =
        BluetoothScanService.devicesFlow
            .map { map ->
                val devList = map.values.toList()
                RadarStats(
                    total = devList.size,
                    closest = devList.filter { it.distance > 0 }.minByOrNull { it.distance }?.let {
                        "%.1fm".format(it.distance)
                    } ?: "—",
                    strongest = devList.maxByOrNull { it.rssi }?.rssi?.let { "$it dBm" } ?: "—",
                    threats = devList.count { it.classification.isThreat }
                )
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), RadarStats())

    // ── Service binding ───────────────────────────────────────────────────────

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            scanService = (binder as BluetoothScanService.LocalBinder).getService()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            scanService = null
        }
    }

    fun bindService(context: Context) {
        val intent = Intent(context, BluetoothScanService::class.java)
        context.startForegroundService(intent)
        context.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    fun unbindService(context: Context) {
        runCatching { context.unbindService(serviceConnection) }
    }

    fun toggleScan() {
        val service = scanService ?: return
        if (BluetoothScanService.scanActiveFlow.value) {
            service.stopBleScan()
        } else {
            service.startBleScan()
        }
    }
}

data class RadarStats(
    val total: Int = 0,
    val closest: String = "—",
    val strongest: String = "—",
    val threats: Int = 0
)
