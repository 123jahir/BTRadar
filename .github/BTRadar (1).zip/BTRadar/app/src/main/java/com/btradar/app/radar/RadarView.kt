package com.btradar.app.radar

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import com.btradar.app.bluetooth.DeviceModel
import kotlin.math.*

/**
 * Custom View that renders the live Bluetooth radar.
 *
 * - Rotating sweep line with fading trail
 * - Concentric range rings (2m, 5m, 10m, 20m)
 * - Devices plotted by estimated distance from center
 * - Device dots glow and pulse on new detection
 * - Tap a dot to select the device
 */
class RadarView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    // ── Paints ─────────────────────────────────────────────────────────────────

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
        color = Color.argb(40, 0, 255, 80)
    }

    private val crosshairPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f
        color = Color.argb(25, 0, 255, 80)
    }

    private val outerRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
        color = Color.argb(80, 0, 255, 80)
    }

    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 0, 255, 80)
        textSize = 24f
        typeface = Typeface.MONOSPACE
    }

    private val centerDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(255, 0, 255, 80)
        setShadowLayer(16f, 0f, 0f, Color.argb(200, 0, 255, 80)!!)
    }

    private val centerLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(160, 0, 255, 80)
        textSize = 22f
        typeface = Typeface.MONOSPACE
    }

    private val deviceDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val deviceLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 22f
        typeface = Typeface.MONOSPACE
    }

    private val deviceRssiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 18f
        typeface = Typeface.MONOSPACE
        color = Color.argb(140, 160, 230, 180)
    }

    private val sweepPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val bgPaint = Paint().apply {
        style = Paint.Style.FILL
    }

    // ── State ──────────────────────────────────────────────────────────────────

    private var devices: List<DeviceModel> = emptyList()
    private var sweepAngle: Float = 0f
    private val sweepSpeed = 2f // degrees per frame (~60fps = ~1 rotation/3s)
    private var selectedMac: String? = null

    var onDeviceSelected: ((DeviceModel?) -> Unit)? = null

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(e: MotionEvent): Boolean {
            handleTap(e.x, e.y)
            return true
        }
    })

    private val MAX_DIST = 25f // meters mapped to edge of radar
    private val RINGS = listOf(2f, 5f, 10f, 20f)

    // ── Public API ─────────────────────────────────────────────────────────────

    fun updateDevices(newDevices: List<DeviceModel>) {
        devices = newDevices
        // No invalidate here — the sweep animation loop handles redraws
    }

    fun setSelectedMac(mac: String?) {
        selectedMac = mac
    }

    // ── Layout ─────────────────────────────────────────────────────────────────

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = min(
            MeasureSpec.getSize(widthMeasureSpec),
            MeasureSpec.getSize(heightMeasureSpec)
        )
        setMeasuredDimension(size, size)
    }

    // ── Touch ──────────────────────────────────────────────────────────────────

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        return true
    }

    private fun handleTap(tapX: Float, tapY: Float) {
        val cx = width / 2f
        val cy = height / 2f
        val R = (min(cx, cy) - 4f)

        val tapped = devices.firstOrNull { d ->
            val (dx, dy) = devicePosition(d, cx, cy, R)
            hypot(tapX - dx, tapY - dy) < 40f
        }

        selectedMac = tapped?.mac
        onDeviceSelected?.invoke(tapped)
        invalidate()
    }

    // ── Drawing ────────────────────────────────────────────────────────────────

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val R = (min(cx, cy) - 4f)

        drawBackground(canvas, cx, cy, R)
        drawRings(canvas, cx, cy, R)
        drawCrosshairs(canvas, cx, cy, R)
        drawSweep(canvas, cx, cy, R)
        drawDevices(canvas, cx, cy, R)
        drawCenter(canvas, cx, cy)

        // Advance sweep
        sweepAngle = (sweepAngle + sweepSpeed) % 360f
        postInvalidateOnAnimation()
    }

    private fun drawBackground(canvas: Canvas, cx: Float, cy: Float, R: Float) {
        bgPaint.shader = RadialGradient(
            cx, cy, R,
            intArrayOf(Color.argb(255, 4, 16, 9), Color.argb(255, 2, 8, 5)),
            floatArrayOf(0f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, R, bgPaint)
    }

    private fun drawRings(canvas: Canvas, cx: Float, cy: Float, R: Float) {
        RINGS.forEach { dist ->
            val r = distToRadius(dist, R)
            canvas.drawCircle(cx, cy, r, ringPaint)
            canvas.drawText(
                "${dist.toInt()}m",
                cx + r + 4f,
                cy - 4f,
                labelPaint
            )
        }
        canvas.drawCircle(cx, cy, R, outerRingPaint)
    }

    private fun drawCrosshairs(canvas: Canvas, cx: Float, cy: Float, R: Float) {
        canvas.drawLine(cx, cy - R, cx, cy + R, crosshairPaint)
        canvas.drawLine(cx - R, cy, cx + R, cy, crosshairPaint)
        // Diagonals at 45°
        val diag = R * 0.707f
        canvas.drawLine(cx - diag, cy - diag, cx + diag, cy + diag, crosshairPaint)
        canvas.drawLine(cx + diag, cy - diag, cx - diag, cy + diag, crosshairPaint)
    }

    private fun drawSweep(canvas: Canvas, cx: Float, cy: Float, R: Float) {
        // Fading sweep tail: 30 segments over 60°
        val tailSpan = 60f
        val steps = 30
        for (i in 0 until steps) {
            val alpha = ((1f - i.toFloat() / steps) * 60f).toInt()
            sweepPaint.color = Color.argb(alpha, 0, 255, 80)
            val startAngle = sweepAngle - tailSpan * (i.toFloat() / steps)
            val endAngle = sweepAngle - tailSpan * ((i + 1).toFloat() / steps)
            val rect = RectF(cx - R, cy - R, cx + R, cy + R)
            canvas.drawArc(rect, startAngle, endAngle - startAngle, true, sweepPaint)
        }

        // Bright sweep line
        val rad = Math.toRadians(sweepAngle.toDouble())
        val lineX = cx + cos(rad).toFloat() * R
        val lineY = cy + sin(rad).toFloat() * R
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2f
            color = Color.argb(200, 0, 255, 80)
            setShadowLayer(8f, 0f, 0f, Color.argb(150, 0, 255, 80)!!)
        }
        canvas.drawLine(cx, cy, lineX, lineY, linePaint)
    }

    private fun drawDevices(canvas: Canvas, cx: Float, cy: Float, R: Float) {
        devices.forEach { d ->
            val (x, y) = devicePosition(d, cx, cy, R)
            val isSelected = selectedMac == d.mac
            val isThreat = d.classification.isThreat

            val dotColor = when {
                isThreat    -> Color.argb(255, 255, 60, 60)
                isSelected  -> Color.argb(255, 0, 255, 80)
                else        -> Color.argb(220, 0, 200, 60)
            }

            val glowColor = when {
                isThreat   -> Color.argb(180, 255, 60, 60)
                isSelected -> Color.argb(180, 0, 255, 80)
                else       -> Color.argb(100, 0, 200, 60)
            }

            val dotRadius = if (isSelected) 14f else 10f

            deviceDotPaint.color = dotColor
            deviceDotPaint.setShadowLayer(if (isSelected) 20f else 10f, 0f, 0f, glowColor)
            canvas.drawCircle(x, y, dotRadius, deviceDotPaint)
            deviceDotPaint.clearShadowLayer()

            // Selection ring
            if (isSelected) {
                val selRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 1.5f
                    color = dotColor
                }
                canvas.drawCircle(x, y, 22f, selRingPaint)
            }

            // Device icon / emoji (draw as text)
            val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 28f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(d.classification.emoji, x, y - 20f, iconPaint)

            // Device label
            val label = (d.name ?: d.mac.takeLast(8)).take(12)
            deviceLabelPaint.color = if (isSelected) dotColor else Color.argb(180, 200, 240, 210)
            deviceLabelPaint.setShadowLayer(if (isSelected) 8f else 0f, 0f, 0f, dotColor)

            val labelX = if (x > cx) x + 16f else x - deviceLabelPaint.measureText(label) - 6f
            val labelY = if (y > cy) y + 30f else y - 10f
            canvas.drawText(label, labelX, labelY, deviceLabelPaint)
            deviceLabelPaint.clearShadowLayer()

            // RSSI
            canvas.drawText("${d.rssi}dBm", labelX, labelY + 18f, deviceRssiPaint)
        }
    }

    private fun drawCenter(canvas: Canvas, cx: Float, cy: Float) {
        canvas.drawCircle(cx, cy, 8f, centerDotPaint)
        canvas.drawText("YOU", cx + 12f, cy - 10f, centerLabelPaint)
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private fun distToRadius(distM: Float, R: Float): Float {
        val capped = distM.coerceAtMost(MAX_DIST)
        return (capped / MAX_DIST) * R * 0.95f
    }

    /**
     * Stable angular position per device — hashed from MAC address.
     * Same device always appears at the same angle on the radar.
     */
    private fun macToAngle(mac: String): Float {
        var h = 0L
        mac.forEach { h = (h * 31 + it.code) and 0xFFFFFFL }
        return (h.toFloat() / 0xFFFFFFL) * 360f
    }

    private fun devicePosition(d: DeviceModel, cx: Float, cy: Float, R: Float): Pair<Float, Float> {
        val dist = if (d.distance > 0) d.distance else 18f
        val r = distToRadius(dist, R)
        val angle = Math.toRadians(macToAngle(d.mac).toDouble())
        return Pair(
            cx + cos(angle).toFloat() * r,
            cy + sin(angle).toFloat() * r
        )
    }
}
