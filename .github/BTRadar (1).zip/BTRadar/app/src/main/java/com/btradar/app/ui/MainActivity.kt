package com.btradar.app.ui

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.btradar.app.bluetooth.DeviceModel
import com.btradar.app.bluetooth.ScanEvent
import com.btradar.app.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    private lateinit var deviceAdapter: DeviceListAdapter
    private lateinit var logAdapter: EventLogAdapter

    // ── Permission Request ─────────────────────────────────────────────────────

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.all { it }) {
            startScanning()
        } else {
            Toast.makeText(this, "Bluetooth permissions are required to scan", Toast.LENGTH_LONG).show()
            binding.btnScan.text = "PERMISSIONS DENIED"
            binding.btnScan.isEnabled = false
        }
    }

    private val enableBluetoothLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        checkPermissionsAndScan()
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerViews()
        setupRadar()
        setupButtons()
        observeViewModel()
        checkPermissionsAndScan()
    }

    override fun onStart() {
        super.onStart()
        viewModel.bindService(this)
    }

    override fun onStop() {
        super.onStop()
        viewModel.unbindService(this)
    }

    // ── Setup ──────────────────────────────────────────────────────────────────

    private fun setupRecyclerViews() {
        deviceAdapter = DeviceListAdapter { device ->
            binding.radarView.setSelectedMac(device.mac)
            showDeviceDetail(device)
        }
        binding.recyclerDevices.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = deviceAdapter
        }

        logAdapter = EventLogAdapter()
        binding.recyclerLog.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = logAdapter
        }
    }

    private fun setupRadar() {
        binding.radarView.onDeviceSelected = { device ->
            if (device != null) showDeviceDetail(device)
            else hideDeviceDetail()
        }
    }

    private fun setupButtons() {
        binding.btnScan.setOnClickListener {
            viewModel.toggleScan()
        }

        binding.tabDevices.setOnClickListener {
            binding.recyclerDevices.visibility = View.VISIBLE
            binding.recyclerLog.visibility = View.GONE
            binding.tabDevices.alpha = 1f
            binding.tabLog.alpha = 0.4f
        }

        binding.tabLog.setOnClickListener {
            binding.recyclerDevices.visibility = View.GONE
            binding.recyclerLog.visibility = View.VISIBLE
            binding.tabDevices.alpha = 0.4f
            binding.tabLog.alpha = 1f
        }

        binding.btnCloseDetail.setOnClickListener {
            hideDeviceDetail()
            binding.radarView.setSelectedMac(null)
        }
    }

    // ── Observe ────────────────────────────────────────────────────────────────

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.devices.collect { devices ->
                deviceAdapter.submitList(devices)
                binding.radarView.updateDevices(devices)
                binding.tvDeviceCount.text = "${devices.size}"
            }
        }

        lifecycleScope.launch {
            viewModel.scanActive.collect { active ->
                binding.btnScan.text = if (active) "■ STOP SCAN" else "▶ START SCAN"
                binding.scanIndicator.visibility = if (active) View.VISIBLE else View.GONE
            }
        }

        lifecycleScope.launch {
            viewModel.stats.collect { stats ->
                binding.tvStatTotal.text = stats.total.toString()
                binding.tvStatClosest.text = stats.closest
                binding.tvStatStrongest.text = stats.strongest
                binding.tvStatThreats.text = stats.threats.toString()
                if (stats.threats > 0) {
                    binding.tvStatThreats.setTextColor(getColor(android.R.color.holo_red_light))
                } else {
                    binding.tvStatThreats.setTextColor(getColor(android.R.color.holo_green_light))
                }
            }
        }

        lifecycleScope.launch {
            viewModel.eventLog.collect { events ->
                logAdapter.submitList(events)
                binding.tvLogCount.text = "${events.size} EVENTS"
            }
        }
    }

    // ── Detail Panel ───────────────────────────────────────────────────────────

    private fun showDeviceDetail(device: DeviceModel) {
        binding.layoutDeviceDetail.visibility = View.VISIBLE
        binding.tvDetailName.text = device.displayName
        binding.tvDetailType.text = "${device.classification.emoji}  ${device.classification.label}"
        binding.tvDetailMac.text = device.mac
        binding.tvDetailRssi.text = "${device.rssi} dBm  (${device.signalQuality.label})"
        binding.tvDetailDistance.text = "~${
            if (device.distance > 0) "%.2f m".format(device.distance) else "?"
        }"
        binding.tvDetailMovement.text = device.movement.name
        binding.tvDetailFirstSeen.text = formatTime(device.firstSeen)
        binding.tvDetailLastSeen.text = formatTime(device.lastSeen)
        binding.tvDetailSeenCount.text = "${device.seenCount}x"
        binding.tvDetailConnectable.text = if (device.connectable) "YES" else "NO"
        binding.tvDetailUuids.text = device.serviceUuids.joinToString(", ").ifEmpty { "None" }
        binding.tvDetailMfg.text = device.manufacturerData?.let {
            it.take(8).joinToString("") { b -> "%02X".format(b) }
                .chunked(2).joinToString(":")
                .let { hex -> if (it.size > 8) "$hex..." else hex }
        } ?: "—"

        if (device.classification.isThreat) {
            binding.tvDetailThreat.visibility = View.VISIBLE
        } else {
            binding.tvDetailThreat.visibility = View.GONE
        }
    }

    private fun hideDeviceDetail() {
        binding.layoutDeviceDetail.visibility = View.GONE
    }

    // ── Permissions & Bluetooth ────────────────────────────────────────────────

    private fun checkPermissionsAndScan() {
        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = bluetoothManager.adapter

        if (adapter == null) {
            Toast.makeText(this, "This device does not support Bluetooth", Toast.LENGTH_LONG).show()
            return
        }

        if (!adapter.isEnabled) {
            enableBluetoothLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            return
        }

        val required = buildRequiredPermissions()
        val missing = required.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isEmpty()) {
            startScanning()
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun buildRequiredPermissions(): List<String> {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms += Manifest.permission.BLUETOOTH_SCAN
            perms += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            perms += Manifest.permission.ACCESS_FINE_LOCATION
        }
        return perms
    }

    private fun startScanning() {
        viewModel.bindService(this)
    }

    private fun formatTime(ms: Long): String {
        val sdf = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
        return sdf.format(java.util.Date(ms))
    }
}
