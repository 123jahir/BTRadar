package com.btradar.app.bluetooth

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.*
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.btradar.app.ui.MainActivity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Foreground service that keeps BLE scanning alive even when app is backgrounded.
 * Uses allowLossyLessCallback = false (ScanSettings.CALLBACK_TYPE_ALL_MATCHES)
 * to receive every advertising packet with fresh RSSI.
 */
class BluetoothScanService : Service() {

    companion object {
        const val NOTIFICATION_CHANNEL_ID = "bt_radar_scan"
        const val NOTIFICATION_ID = 1001

        // Broadcast Actions
        const val ACTION_DEVICE_FOUND  = "com.btradar.DEVICE_FOUND"
        const val ACTION_SCAN_STATUS   = "com.btradar.SCAN_STATUS"
        const val EXTRA_SCAN_ACTIVE    = "scan_active"

        // Singleton state flows accessible from ViewModel
        val devicesFlow = MutableStateFlow<Map<String, DeviceModel>>(emptyMap())
        val scanActiveFlow = MutableStateFlow(false)
        val eventLogFlow = MutableStateFlow<List<ScanEvent>>(emptyList())
    }

    private val binder = LocalBinder()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var bluetoothLeScanner: BluetoothLeScanner? = null
    private var scanCallback: ScanCallback? = null
    private val devices = mutableMapOf<String, DeviceModel>()

    // Stale device cleanup job
    private var cleanupJob: Job? = null

    inner class LocalBinder : Binder() {
        fun getService(): BluetoothScanService = this@BluetoothScanService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Initializing scanner..."))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startBleScan()
        return START_STICKY
    }

    // ── BLE Scanning ──────────────────────────────────────────────────────────

    fun startBleScan() {
        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter: BluetoothAdapter = bluetoothManager.adapter ?: return

        if (!adapter.isEnabled) return

        bluetoothLeScanner = adapter.bluetoothLeScanner ?: return

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)         // fastest scan, more battery
            .setCallbackType(ScanSettings.CALLBACK_TYPE_ALL_MATCHES) // every advertising packet
            .setReportDelay(0)                                        // immediate delivery
            .build()

        // No filters → detect ALL nearby BLE devices
        val filters = emptyList<ScanFilter>()

        scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                processScanResult(result)
            }

            override fun onBatchScanResults(results: List<ScanResult>) {
                results.forEach { processScanResult(it) }
            }

            override fun onScanFailed(errorCode: Int) {
                scanActiveFlow.value = false
                updateNotification("Scan failed (error $errorCode)")
            }
        }

        bluetoothLeScanner?.startScan(filters, settings, scanCallback)
        scanActiveFlow.value = true
        updateNotification("Scanning for devices...")

        startCleanupJob()
    }

    fun stopBleScan() {
        scanCallback?.let { bluetoothLeScanner?.stopScan(it) }
        scanCallback = null
        scanActiveFlow.value = false
        cleanupJob?.cancel()
        updateNotification("Scan paused")
    }

    // ── Process Each Advertising Packet ───────────────────────────────────────

    private fun processScanResult(result: ScanResult) {
        val device = result.device
        val mac = device.address
        val rssi = result.rssi
        val record = result.scanRecord

        val name = record?.deviceName ?: runCatching { device.name }.getOrNull()
        val serviceUuids = record?.serviceUuids?.map { it.uuid.toString() } ?: emptyList()
        val mfgData = record?.manufacturerSpecificData?.let { sparse ->
            if (sparse.size() > 0) sparse.valueAt(0) else null
        }
        val txPower = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            result.txPower.takeIf { it != ScanResult.TX_POWER_NOT_PRESENT }
        else
            record?.txPowerLevel?.takeIf { it != Integer.MIN_VALUE }

        val now = System.currentTimeMillis()
        val existing = devices[mac]

        // Update RSSI history (last 10 readings)
        val rssiHistory = existing?.rssiHistory?.toMutableList() ?: mutableListOf()
        rssiHistory.add(rssi)
        if (rssiHistory.size > 10) rssiHistory.removeAt(0)

        val distance = SignalAnalyzer.estimateDistance(rssi, txPower)
        val movement = SignalAnalyzer.detectMovement(rssiHistory)
        val classification = DeviceClassifier.classify(name, serviceUuids, mfgData)
        val isNew = existing == null

        val updated = DeviceModel(
            mac = mac,
            name = name ?: existing?.name,
            rssi = rssi,
            rssiHistory = rssiHistory,
            distance = distance,
            signalQuality = DeviceModel.signalQualityFromRssi(rssi),
            classification = classification,
            movement = movement,
            firstSeen = existing?.firstSeen ?: now,
            lastSeen = now,
            seenCount = (existing?.seenCount ?: 0) + 1,
            txPower = txPower,
            serviceUuids = serviceUuids,
            connectable = result.isConnectable,
            manufacturerData = mfgData,
            isNew = isNew
        )

        devices[mac] = updated

        // Emit updated snapshot
        devicesFlow.value = devices.toMap()

        // Log new device appearances
        if (isNew) {
            addEvent(ScanEvent(
                time = now,
                type = ScanEvent.Type.APPEARED,
                mac = mac,
                name = name,
                distance = distance,
                classificationLabel = classification.label
            ))
        }

        // Alert for trackers
        if (isNew && classification.isThreat) {
            addEvent(ScanEvent(
                time = now,
                type = ScanEvent.Type.ALERT,
                mac = mac,
                name = name,
                distance = distance,
                classificationLabel = classification.label,
                message = "Tracker detected: ${classification.label}"
            ))
            updateNotification("⚠ TRACKER DETECTED: ${name ?: mac}")
        }
    }

    // ── Stale Device Cleanup (remove devices not seen in 30s) ─────────────────

    private fun startCleanupJob() {
        cleanupJob?.cancel()
        cleanupJob = scope.launch {
            while (isActive) {
                delay(5000)
                val now = System.currentTimeMillis()
                val stale = devices.filter { (_, d) -> now - d.lastSeen > 30_000 }.keys.toList()
                if (stale.isNotEmpty()) {
                    stale.forEach { mac ->
                        val d = devices[mac]
                        devices.remove(mac)
                        d?.let {
                            addEvent(ScanEvent(
                                time = now,
                                type = ScanEvent.Type.DISAPPEARED,
                                mac = mac,
                                name = it.name,
                                distance = it.distance,
                                classificationLabel = it.classification.label
                            ))
                        }
                    }
                    devicesFlow.value = devices.toMap()
                }
                updateNotification("Active: ${devices.size} device${if (devices.size != 1) "s" else ""}")
            }
        }
    }

    private fun addEvent(event: ScanEvent) {
        val current = eventLogFlow.value.toMutableList()
        current.add(0, event)
        if (current.size > 200) current.removeAt(current.lastIndex)
        eventLogFlow.value = current
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            NOTIFICATION_CHANNEL_ID,
            "BT Radar Scanner",
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Active Bluetooth scanning" }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String) =
        NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("BT Radar — Scanning")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0,
                    Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE
                )
            )
            .build()

    private fun updateNotification(text: String) {
        val mgr = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        mgr.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        super.onDestroy()
        stopBleScan()
        scope.cancel()
    }
}

data class ScanEvent(
    val time: Long,
    val type: Type,
    val mac: String,
    val name: String?,
    val distance: Float,
    val classificationLabel: String,
    val message: String? = null
) {
    enum class Type { APPEARED, DISAPPEARED, ALERT }
}
