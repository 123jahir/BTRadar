package com.btradar.app.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.btradar.app.bluetooth.DeviceModel
import com.btradar.app.bluetooth.SignalAnalyzer

class DeviceListAdapter(
    private val onDeviceClick: (DeviceModel) -> Unit
) : ListAdapter<DeviceModel, DeviceListAdapter.VH>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_2, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(getItem(position), onDeviceClick)
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        private val text1: TextView = view.findViewById(android.R.id.text1)
        private val text2: TextView = view.findViewById(android.R.id.text2)

        fun bind(device: DeviceModel, onClick: (DeviceModel) -> Unit) {
            val distStr = SignalAnalyzer.formatDistance(device.distance)
            val mvArrow = when (device.movement) {
                DeviceModel.Movement.APPROACHING -> " ▲"
                DeviceModel.Movement.RECEDING    -> " ▼"
                else                             -> ""
            }

            text1.text = "${device.classification.emoji} ${device.displayName}$mvArrow"
            text2.text = "${device.rssi} dBm  ·  ~$distStr  ·  ${device.classification.label}"

            val rssiColor = when {
                device.rssi >= -50 -> Color.parseColor("#00ff6a")
                device.rssi >= -60 -> Color.parseColor("#80ff80")
                device.rssi >= -70 -> Color.parseColor("#ffb300")
                device.rssi >= -80 -> Color.parseColor("#ff8c00")
                else               -> Color.parseColor("#ff3b3b")
            }
            text1.setTextColor(if (device.classification.isThreat) Color.parseColor("#ff3b3b") else rssiColor)
            text2.setTextColor(Color.parseColor("#4a7a5a"))

            itemView.setBackgroundColor(
                if (device.classification.isThreat)
                    Color.argb(30, 255, 60, 60)
                else
                    Color.TRANSPARENT
            )

            itemView.setOnClickListener { onClick(device) }
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<DeviceModel>() {
            override fun areItemsTheSame(a: DeviceModel, b: DeviceModel) = a.mac == b.mac
            override fun areContentsTheSame(a: DeviceModel, b: DeviceModel) =
                a.rssi == b.rssi && a.distance == b.distance && a.movement == b.movement
        }
    }
}
