package com.btradar.app.bluetooth

import kotlin.math.pow

/**
 * Converts raw RSSI values into distance estimates and movement direction.
 *
 * Uses the Log-Distance Path Loss model:
 *   distance = 10 ^ ((txPower - rssi) / (10 * n))
 *
 *   txPower = measured RSSI at 1 meter (default -59 dBm for BLE)
 *   n = path loss exponent (2.0 = free space, 2.5-3.5 = indoor)
 */
object SignalAnalyzer {

    private const val DEFAULT_TX_POWER = -59   // dBm at 1 meter (BLE standard)
    private const val PATH_LOSS_EXPONENT = 2.5 // indoor environment

    /**
     * Estimate distance in meters from RSSI.
     * Returns -1 if RSSI is invalid.
     */
    fun estimateDistance(rssi: Int, txPower: Int? = null): Float {
        if (rssi == 0) return -1f
        val tx = txPower ?: DEFAULT_TX_POWER
        val ratio = (tx - rssi) / (10.0 * PATH_LOSS_EXPONENT)
        return 10.0.pow(ratio).toFloat()
    }

    /**
     * Detect movement from RSSI history.
     * Compare average of oldest 3 vs newest 3 samples.
     * +4 dBm change = meaningful movement threshold.
     */
    fun detectMovement(rssiHistory: List<Int>): DeviceModel.Movement {
        if (rssiHistory.size < 6) return DeviceModel.Movement.STABLE

        val oldAvg = rssiHistory.take(3).average()
        val newAvg = rssiHistory.takeLast(3).average()
        val delta = newAvg - oldAvg

        return when {
            delta > 4  -> DeviceModel.Movement.APPROACHING
            delta < -4 -> DeviceModel.Movement.RECEDING
            else       -> DeviceModel.Movement.STABLE
        }
    }

    /**
     * Format distance for display. <1m shown as cm.
     */
    fun formatDistance(distanceM: Float): String {
        if (distanceM < 0) return "?"
        return when {
            distanceM < 1f  -> "${(distanceM * 100).toInt()} cm"
            distanceM < 10f -> "%.1f m".format(distanceM)
            else            -> "${distanceM.toInt()} m"
        }
    }

    /**
     * Map RSSI to 0-100 signal strength percentage for UI bars
     */
    fun rssiToPercent(rssi: Int): Int {
        // Range: -100 dBm (0%) to -40 dBm (100%)
        val clamped = rssi.coerceIn(-100, -40)
        return ((clamped + 100) / 60.0 * 100).toInt()
    }
}
